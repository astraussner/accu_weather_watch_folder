# -*- coding: utf-8 -*-

from __future__ import absolute_import

__version__ = '1.2.2'

import sys
PY3 = sys.version_info > (3,)

from .client import Client
